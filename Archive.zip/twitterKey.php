<?php
/**
 * Created by PhpStorm.
 * User: bunny
 * Date: 22/08/17
 * Time: 5:29 PM
 */

define('CONSUMER_KEY', 'yOTtNuIyaEBGT825culpz6ZQ8');
define('CONSUMER_SECRET', 'lNahQ7OXdn4yoKG2eSLxbOtDcipg9IJ9YBdKeysBbiErdk2uzg');
define('ACCESS_TOKEN', '3772433354-EwlnWXPKJGAoSwefwrIA7jVPNppXgV1bzHFUyr2');
define('ACCESS_TOKEN_SECRET', 'g6j4OlJG5HaKSkD87WDjvUM3GBWJWbAM8sGWHnn67CwAn');